// a is the unknown angle (aka theta in trig)
// k is the constant (trig)
// r is the radius

// r=cos(k*theta)
// source: https://en.wikipedia.org/wiki/Rose_(mathematics)

// SOH sin(theta) = y/r  or y = r* sin(theta)
// CAH cos(theta) = x/r  or x = r* cos(theta) r
// TOA tan(theta) = y/x  or y = x* tan(theta)
//let angle = 0


function setup() {
  //createCanvas(windowWidth, windowHeight, WEBGL);

  createCanvas(windowWidth, windowHeight, WEBGL);
  angleMode(DEGREES);
  
  
}

function draw() {
  //background(255);
  background(40);
  //background('rgba(100%,100%,100%,0.1)');

  //translate(width / 2, height / 2)

  noFill();
  //stroke('rgba(40%,40%,40%,0.08)');
  stroke('rbga (68%, 77%, 81%,1)');
  strokeWeight(0.19);


  for (var i = 0; i < 50; i++) {
    beginShape();

    //for (var a = 0; a < TWO_PI; a += 0.04) {

    for (var a = 0; a < 360; a += 10) {
      var r = i * 8;
      var x = r * cos(a);
      var y = r * sin(a);
      var z = sin(frameCount) * 275;


      //translate(0, 10)

      vertex(x, y, z);
      //ellipse(x, y, r, r);
    }
    endShape(CLOSE);
  }
    
//     for (var i = 0; i < 10; i++) {
//     beginShape();

//     //for (var a = 0; a < TWO_PI; a += 0.04) {

//     for (var a = 0; a < 360; a +=10) {
//       var r = 4 *sin(i * 8);
//       var x = r * cos(a);
//       var y = r * sin(a);
//       var z = sin(frameCount + i * 10) * 75;


//       //translate(0, 10)

//       vertex(x, y, z);
//       //ellipse(x, y, r, r);
//     }
//     endShape(CLOSE);
//   }
  
  
}


// for (var a = 0; a < TWO_PI; a += 0.04) {
//   var r = 900 * sin(30 / a + 12000);
//   var x = r * sin(0);
//   var y = r * sin(0);


//     noFill();
//     stroke('rgba(40%,40%,40%,0.08)');
//     strokeWeight(0.3);

//fill('rgba(5%,50%,100%,0.0019456)');

// push();
// translate(x,y);
// rotate(angle);
// scale(4);
// ellipse(0,0, r,r)
// //ellipse(x,y,r,r);
// pop();


//ellipse(x, y, r, r);

//angle =angle +2

//   }
// }

// function windowResized() {
//   resizeCanvas(windowWidth, windowHeight);
// }