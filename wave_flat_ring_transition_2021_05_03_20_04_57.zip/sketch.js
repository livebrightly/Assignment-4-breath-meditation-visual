// a is the unknown angle (aka theta in trig)
// k is the constant (trig)
// r is the radius

// r=cos(k*theta)
// source: https://en.wikipedia.org/wiki/Rose_(mathematics)

// SOH sin(theta) = y/r  or y = r* sin(theta)
// CAH cos(theta) = x/r  or x = r* cos(theta)
// TOA tan(theta) = y/x  or y = x* tan(theta)
let angle = 0

function setup() {
  //createCanvas(windowWidth, windowHeight);
  
    
  createCanvas(1000, 1000, WEBGL);
  angleMode(DEGREES);
}

function draw() {
  //background(255);
  background('rgba(100%,100%,100%,0.1)');

  //translate(width/2, height/2)

  
  
  for (var a = 0; a < TWO_PI; a+=0.04) {
   var r = 900*sin(3*a +1200);
   var x = r* sin(0);
   var y = r* sin(0);
    
    
    c = color('hsba(160, 100%, 50%, 0.5)');
    stroke(c)
    //stroke('rbga(40%, 68%,70%, 1)' )
    //stroke('rgba(40%,40%,40%,0.08)');
    strokeWeight(3);
    noFill();
    //fill('rgba(5%,50%,100%,0.0019456)');
    
    push();
    translate(x,y);
    rotate(angle);
    scale(1);
    ellipse(0,0, r,r)
    //ellipse(x,y,r,r);
    pop();
    
    
    //ellipse(x,y,r,r);

    angle =angle +2
    
  }
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}